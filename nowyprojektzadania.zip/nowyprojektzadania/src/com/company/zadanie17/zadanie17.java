package com.company.zadanie17;

import com.company.helper;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class zadanie17 {
    public static void main(String[] args) {
        howLongTillEnteredDate(helper.getLocalDateFroamConsole());
    }
    public static void howLongTillEnteredDate(LocalDate data){
        LocalDate now = LocalDate.now();
        System.out.println("Time remain: " + ChronoUnit.DAYS.between(now,data) + " days"  );
    }
}
