package com.company;

import java.util.Scanner;

public class helper {
    public static int pobierzInta() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj inta: ");
        return scanner.nextInt();
    }
}
